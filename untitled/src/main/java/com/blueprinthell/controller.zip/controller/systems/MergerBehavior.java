package com.blueprinthell.controller.systems;

import com.blueprinthell.config.Config;
import com.blueprinthell.model.PacketLossModel;
import com.blueprinthell.model.PacketModel;
import com.blueprinthell.model.PacketType;
import com.blueprinthell.model.PortModel;
import com.blueprinthell.model.SystemBoxModel;
import com.blueprinthell.model.large.BitPacket;
import com.blueprinthell.model.large.LargeGroupRegistry;
import com.blueprinthell.model.large.LargeGroupRegistry.GroupState;
import com.blueprinthell.model.large.LargePacket;
import com.blueprinthell.motion.KinematicsRegistry;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * MergerBehavior – **extra‑verbose debug edition**.
 * <p>
 *   ↳ جمع‌آوری BitPacketها، ادغام چهارتایی به LargePacket (سایز ۴) و گزارش دقیق تمام گام‌ها.
 * <p>
 *   روشن/خاموش‌کردن لاگ با ثابت {@link #DEBUG}. در حالت DEBUG=false تمام دستورات log نادیده گرفته می‌شود.
 *
 *   <strong>LOSS NOTE:</strong>‌ هر بیتِ باقیمانده که به بستهٔ بزرگ تبدیل نشود، «از‑دست‑رفته» در نظر گرفته می‌شود و باید در
 *   {@link PacketLossModel} ثبت شود. فعلاً فقط این کامنت اضافه شده تا این موضوع روشن باشد.
 */
public final class MergerBehavior implements SystemBehavior {

    /* === Tunables ====================================================== */
    private static final int  BITS_PER_MERGE  = 4;
    private static final int  MERGED_PKT_SIZE = 4;
    public  static final boolean DEBUG       = true;   // ← تغییر دهید

    /* === Dependencies ================================================== */
    private final SystemBoxModel     box;
    private final LargeGroupRegistry registry;
    private final PacketLossModel    lossModel;

    /* === State ========================================================= */
    private final Map<Integer, GroupContext> groups = new HashMap<>();

    /* =================================================================== */
    /*  ctor                                                               */
    /* =================================================================== */
    public MergerBehavior(SystemBoxModel box,
                          LargeGroupRegistry registry,
                          PacketLossModel lossModel) {
        this.box       = Objects.requireNonNull(box, "box");
        this.registry  = Objects.requireNonNull(registry, "registry");
        this.lossModel = Objects.requireNonNull(lossModel, "lossModel");
    }

    /* =================================================================== */
    /*  SystemBehavior callbacks                                           */
    /* =================================================================== */

    @Override
    public void onPacketEnqueued(PacketModel p, PortModel entered) {
        if (!(p instanceof BitPacket bp)) return;

        /** Step‑1: remove from box buffer **/
        boolean removed = box.getBuffer().remove(bp);
        log("ARRIVE  ▸ gid=" + bp.getGroupId() + "  rem=" + removed + "  bufSize=" + box.getBuffer().size());
        if (!removed) return;   // duplicate safety

        /** Step‑2: obtain context **/
        GroupContext ctx = groups.computeIfAbsent(bp.getGroupId(), gid -> {
            log("CTX‑NEW ▸ gid=" + gid);
            return new GroupContext(gid);
        });
        ctx.bits.add(bp);
        log("CTX‑UPD ▸ gid=" + ctx.groupId + "  bits=" + ctx.bits.size() + "  pend=" + ctx.pending.size());

        /** Step‑3: ensure registry record **/
        ensureRegistry(ctx, bp);

        /** Step‑4: attempt merge immediately **/
        tryMerge(ctx, "enqueue");
    }

    @Override
    public void update(double dt) {
        if (!DEBUG) {
            // fast path – minimal overhead
            for (GroupContext g : groups.values()) tryMerge(g, null);
            return;
        }
        log("=== MergerBehavior.update(dt=" + dt + ")  ctxCount=" + groups.size() + " ===");
        groups.values().forEach(g -> tryMerge(g, "update"));
    }

    @Override public void onEnabledChanged(boolean enabled) {/* no‑op */}

    /* =================================================================== */
    /*  Merge core                                                         */
    /* =================================================================== */

    private void tryMerge(GroupContext ctx, String source) {
        while (ctx.ready()) {
            List<BitPacket> slice = new ArrayList<>(ctx.bits.subList(0, BITS_PER_MERGE));
            log("MERGE?  ▸ gid=" + ctx.groupId + "  src=" + source + "  slice=" + slice.size() +
                    "  bufCap=" + (Config.MAX_BUFFER_CAPACITY - box.getBuffer().size()));

            LargePacket merged = createMergedPacket(slice);
            if (merged == null) {
                log("ERROR   ▸ createMergedPacket returned null – should never happen");
                return;
            }

            /* Attempt to enqueue */
            boolean ok = box.enqueue(merged);
            if (!ok) {
                ctx.pending.addAll(slice);
                log("BUFFER! ▸ gid=" + ctx.groupId + "  bufferFull, pending=" + ctx.pending.size());
                /* break – wait till next frame */
                break;
            }

            /* success */
            ctx.bits.subList(0, BITS_PER_MERGE).clear();
            ctx.pending.removeAll(slice);
            ctx.mergeCount++;
            registry.registerPartialMerge(ctx.groupId, BITS_PER_MERGE, MERGED_PKT_SIZE);

            log("MERGED  ▸ gid=" + ctx.groupId + "  m#=" + ctx.mergeCount +
                    "  remain=" + ctx.bits.size() + "  bufSize=" + box.getBuffer().size());
        }

        maybeCloseGroup(ctx);
    }

    private void ensureRegistry(GroupContext ctx, BitPacket bp) {
        GroupState st = registry.get(ctx.groupId);
        if (st == null) {
            registry.createGroupWithId(ctx.groupId, bp.getParentSizeUnits(), bp.getParentSizeUnits(), bp.getColorId());
            log("REG‑NEW ▸ gid=" + ctx.groupId + "  expectedBits=" + bp.getParentSizeUnits());
        }
        registry.registerArrival(ctx.groupId, bp);
    }

    private void maybeCloseGroup(GroupContext ctx) {
        GroupState st = registry.get(ctx.groupId);
        if (st == null) return;

        int mergedBits = ctx.mergeCount * BITS_PER_MERGE;
        int outstanding = ctx.bits.size() + ctx.pending.size();
        log("CHECK   ▸ gid=" + ctx.groupId + "  merged=" + mergedBits + "  outstanding=" + outstanding +
                "  expected=" + st.expectedBits);

        if (!ctx.isDone() || mergedBits + outstanding < st.expectedBits) return;

        // NOTE: remaining "outstanding" bits are considered LOSS and must be recorded via lossModel.
        log("CLOSE   ▸ gid=" + ctx.groupId + "  finalMergedBits=" + mergedBits);
        closeGroup(ctx);
    }

    /* =================================================================== */
    /*  Helpers                                                            */
    /* =================================================================== */

    private LargePacket createMergedPacket(List<BitPacket> bits) {
        BitPacket first = bits.get(0);
        Color c = Color.getHSBColor(first.getColorId() / 360f, 0.8f, 0.9f);
        LargePacket lp = new LargePacket(PacketType.SQUARE, Config.DEFAULT_PACKET_SPEED, MERGED_PKT_SIZE);
        lp.setCustomColor(c);
        int px = MERGED_PKT_SIZE * Config.PACKET_SIZE_MULTIPLIER;
        lp.setWidth(px); lp.setHeight(px);
        lp.setGroupInfo(first.getGroupId(), BITS_PER_MERGE, first.getColorId());
        KinematicsRegistry.copyProfile(first, lp);
        return lp;
    }

    private void closeGroup(GroupContext ctx) {
        int total = ctx.mergeCount * BITS_PER_MERGE;
        registry.registerPartialMerge(ctx.groupId, total, MERGED_PKT_SIZE);
        registry.closeGroup(ctx.groupId);
        registry.removeGroup(ctx.groupId);
        groups.remove(ctx.groupId);
        log("REMOVED ▸ gid=" + ctx.groupId + "  totalBits=" + total + "  ctxLeft=" + groups.size());
    }

    /* =================================================================== */
    /*  Inner context                                                      */
    /* =================================================================== */

    private static final class GroupContext {
        final int groupId;
        final List<BitPacket> bits = new ArrayList<>();
        final Set<BitPacket> pending = new HashSet<>();
        int mergeCount = 0;
        GroupContext(int id) { this.groupId = id; }
        boolean ready()  { return bits.size() >= BITS_PER_MERGE; }
        boolean isDone() { return bits.isEmpty() && pending.isEmpty(); }
    }

    /* =================================================================== */
    /*  Logging                                                            */
    /* =================================================================== */
    private static void log(String m) { if (DEBUG) System.out.println("[Merger] " + m);}

    public void clear() { groups.clear(); }
}
