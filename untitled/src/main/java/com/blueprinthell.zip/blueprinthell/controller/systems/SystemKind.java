package com.blueprinthell.controller.systems;




public enum SystemKind {
    NORMAL,
    SPY,
    MALICIOUS,
    VPN,
    ANTI_TROJAN,
    DISTRIBUTOR,
    MERGER
}