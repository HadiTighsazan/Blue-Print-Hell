package com.blueprinthell.controller;

import com.blueprinthell.config.Config;
import com.blueprinthell.model.*;

import java.util.List;
import java.util.Map;

/**
 * Produces a **stream** of packets from all source boxes with a fixed interval between emits.
 * تنها یک بار با startProduction() فعال می‌شود و تا تولید تمام پکت‌های مرحله ادامه می‌یابد.
 */
public class PacketProducerController implements Updatable {

    private final List<SystemBoxModel> sourceBoxes;
    private final List<WireModel>      wires;
    private final Map<WireModel, SystemBoxModel> destMap;
    private final double baseSpeed;

    /* -------- streaming params -------- */
    private static final double INTERVAL_SEC = 0.4;   // فاصله زمانی بین ارسال دو پکت روی یک پورت
    private double acc   = 0;                         // time accumulator
    private boolean running = false;                  // جریان فعال است؟

    /* -------- counters -------- */
    private final int totalToProduce;  // کل پکت‌های این مرحله
    private int producedCount = 0;     // تاکنون تولید شده

    public PacketProducerController(List<SystemBoxModel> sourceBoxes,
                                    List<WireModel> wires,
                                    Map<WireModel, SystemBoxModel> destMap,
                                    double baseSpeed) {
        this.sourceBoxes = sourceBoxes;
        this.wires       = wires;
        this.destMap     = destMap;
        this.baseSpeed   = baseSpeed;

        int outs = 0;
        for (SystemBoxModel b : sourceBoxes) outs += b.getOutPorts().size();
        this.totalToProduce = outs * Config.PACKETS_PER_PORT;
    }

    /* ------------ API ------------ */
    public void startProduction() { running = true; }
    public void stopProduction()  { running = false; }
    public boolean isFinished()   { return producedCount >= totalToProduce; }
    public int  getProducedCount() { return producedCount; }

    @Override
    public void update(double dt) {
        if (!running || isFinished()) return;
        acc += dt;
        while (acc >= INTERVAL_SEC && !isFinished()) {
            acc -= INTERVAL_SEC;
            emitOnce();
        }
    }

    /** Emits one packet on every source out‑port (so نوبتی بین همهٔ پورت‌ها). */
    private void emitOnce() {
        for (SystemBoxModel box : sourceBoxes) {
            if (!box.getInPorts().isEmpty()) continue; // safety
            box.getOutPorts().forEach(port -> {
                wires.stream()
                        .filter(w -> w.getSrcPort() == port)
                        .findFirst()
                        .ifPresent(wire -> {
                            if (producedCount < totalToProduce) {
                                PacketType type = port.getType();
                                PacketModel pkt = new PacketModel(type, baseSpeed);
                                wire.attachPacket(pkt, 0.01);
                                producedCount++;
                            }
                        });
            });
        }
        if (isFinished()) running = false;
    }
}
