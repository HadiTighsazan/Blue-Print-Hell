package com.blueprinthell.controller.core;

import com.blueprinthell.config.Config;
import com.blueprinthell.controller.*;
import com.blueprinthell.level.LevelDefinition;
import com.blueprinthell.level.LevelGenerator;
import com.blueprinthell.level.LevelManager;
import com.blueprinthell.model.SystemBoxModel;
import com.blueprinthell.model.Updatable;
import com.blueprinthell.model.WireModel;
import com.blueprinthell.model.WireUsageModel;
import com.blueprinthell.view.WireView;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LevelCoreManager {
    private final GameController gameController;
    public final WireUsageModel usageModel = new WireUsageModel(1000.0);
    public final Map<WireModel, SystemBoxModel> destMap = new HashMap<WireModel, SystemBoxModel>();
    public LevelBuilder levelBuilder;

    public List<SystemBoxModel> boxes = new ArrayList<SystemBoxModel>();
    public LevelManager levelManager;

    public LevelDefinition currentDef;

    public LevelCoreManager(GameController gameController) {
        this.gameController = gameController;
    }

    public WireUsageModel getUsageModel() {
        return usageModel;
    }

    public Map<WireModel, SystemBoxModel> getDestMap() {
        return destMap;
    }

    public LevelBuilder getLevelBuilder() {
        return levelBuilder;
    }

    public List<SystemBoxModel> getBoxes() {
        return boxes;
    }

    public LevelManager getLevelManager() {
        return levelManager;
    }

    public LevelDefinition getCurrentDef() {
        return currentDef;
    }

    public void startLevel(int idx) {
        LevelDefinition def = LevelGenerator.firstLevel();
        for (int i = 1; i < idx; i++) {
            def = LevelGenerator.nextLevel(def);
        }
        startLevel(def);
    }


    public void startLevel(LevelDefinition def) {
        this.currentDef = def;

        if (levelManager == null) {
            throw new IllegalStateException("LevelManager must be set before starting level");
        }

        // توقف و پاک‌سازی Updatableها
        gameController.getSimulation().stop();
        gameController.getSimulation().clearUpdatables();

        // مدل‌های گذرا/تایم‌لاین
        gameController.getScoreModel().reset();
        gameController.getCoinModel().reset();
        gameController.getLossModel().reset();
        gameController.getSnapshotMgr().clear();
        gameController.getTimeline().pause(); // بهتر از resume اینجاست؛ Start دکمه کار را شروع می‌کند

        // حتماً: پاک کردن پکت‌ها و بافرها قبل از بازچینی UI
        if (gameController.getWires() != null) {
            for (WireModel w : gameController.getWires()) {
                w.clearPackets();
            }
        }
        if (boxes != null) {
            for (SystemBoxModel b : boxes) {
                b.clearBuffer();
            }
        }

        // تنظیم بودجهٔ سیم
        usageModel.reset(def.totalWireLength());

        // بازسازی/به‌روزرسانی باکس‌ها و چیدمان روی صحنه
        boxes = levelBuilder.build(def, boxes);

        // سیم‌های موجود (که از قبل بودند) برای مراحل قبلی علامت‌گذاری می‌شوند
        for (WireModel w : gameController.getWires()) {
            w.setForPreviousLevels(true);
        }

        // کنترلرهای ساخت/حذف سیم
        buildWireControllers();

        // استخراج سورس‌ها/سینک از تعریف مرحله
        java.util.List<SystemBoxModel> sources = new java.util.ArrayList<>();
        SystemBoxModel sink = null;
        for (int i = 0; i < boxes.size(); i++) {
            LevelDefinition.BoxSpec spec = def.boxes().get(i);
            SystemBoxModel box = boxes.get(i);
            if (spec.isSource()) sources.add(box);
            if (spec.isSink())   sink = box;
        }

        // اطلاع به WireModel برای منطق بازگشت و فعال/غیرفعال بودن سیستم‌ها
        WireModel.setSourceInputPorts(sources);
        WireModel.setSimulationController(gameController.getSimulation());

        // برنامه‌ریزی تولید: 3 × شماره لول × تعداد پورت‌های خروجی مجموع سورس‌ها
        int stageIndex = levelManager.getLevelIndex() + 1;
        int perPortCount = com.blueprinthell.config.Config.PACKETS_PER_PORT * stageIndex;
        int totalOutPorts = sources.stream().mapToInt(b -> b.getOutPorts().size()).sum();
        int plannedPackets = perPortCount * totalOutPorts;

        // Producer تازه
        gameController.setProducerController(new PacketProducerController(
                sources, gameController.getWires(), destMap,
                com.blueprinthell.config.Config.DEFAULT_PACKET_SPEED,
                perPortCount));
        gameController.getHudCoord().wireLevel(gameController.getProducerController());
        gameController.getSimulation().setPacketProducerController(gameController.getProducerController());

        // PacketRenderer تازه و ریفرش آنی (تا هر ویوی قدیمی کاملاً حذف شود)
        gameController.setPacketRenderer(
                new PacketRenderController(gameController.getGameView().getGameArea(), gameController.getWires()));
        gameController.getPacketRenderer().refreshAll();

        // Hud/Shop و بقیه
        gameController.setHudController(new HudController(
                usageModel, gameController.getLossModel(), gameController.getCoinModel(),
                levelManager, gameController.getHudView()));

        gameController.setShopController(new ShopController(
                gameController.getMainFrame(), gameController.getSimulation(), gameController.getCoinModel(),
                gameController.getCollisionController(), gameController.getLossModel(),
                gameController.getWires(), gameController.getHudController()));

        // Registrar تازه و رجیستر همهٔ کنترلرها (Producer/Dispatcher/Router/Collision/Renderer/…)
        gameController.setRegistrar(new SimulationRegistrar(
                gameController.getSimulation(),
                gameController.getScreenController(),
                gameController.getCollisionController(),
                gameController.getPacketRenderer(),
                gameController.getScoreModel(),
                gameController.getCoinModel(),
                gameController.getLossModel(),
                usageModel,
                gameController.getSnapshotMgr(),
                gameController.getHudView(),
                levelManager
        ));

        java.util.List<Updatable> systemControllers = new java.util.ArrayList<>();
        systemControllers.add(gameController.getHudController());

        gameController.getRegistrar().registerAll(
                boxes,
                gameController.getWires(),
                gameController.getDestMap(),
                sources,
                sink,
                gameController.getProducerController(),
                systemControllers
        );

        // وضعیت دکمه Start
        updateStartEnabled();
        gameController.getHudCoord().refresh();

        // نمایش صفحه بازی
        gameController.getScreenController().showScreen(com.blueprinthell.controller.ScreenController.GAME_SCREEN);
    }


    public void buildWireControllers() {
        WireCreationController creator = new WireCreationController(
                gameController.getGameView(), gameController.getSimulation(), boxes, gameController.getWires(), destMap, usageModel, gameController.getCoinModel(), gameController::updateStartEnabled);
        gameController.setWireCreator(creator);

        new WireRemovalController(
                gameController.getGameView(), gameController.getWires(), destMap, creator, usageModel, gameController::updateStartEnabled);
    }
    public void updateStartEnabled() {
        boolean allConnected = boxes.stream().allMatch(b ->
                b.getInPorts().stream().allMatch(gameController::isPortConnected) &&
                        b.getOutPorts().stream().allMatch(gameController::isPortConnected));
        gameController.getHudCoord().setStartEnabled(allConnected);
    }


    public void purgeCurrentLevelWires() {
        JPanel area = gameController.getGameView().getGameArea();

        List<WireModel> toRemove = new ArrayList<WireModel>();
        for (WireModel w : gameController.getWires()) {
            if (!w.isForPreviousLevels()) {
                if (gameController.getWireCreator() != null) {
                    gameController.getWireCreator().freePortsForWire(w);
                }
                usageModel.freeWire(w.getLength());
                destMap.remove(w);
                toRemove.add(w);
            }
        }

        if (toRemove.isEmpty()) return;

        Component[] comps = area.getComponents();
        for (Component c : comps) {
            if (c instanceof WireView wv) {
                if (toRemove.contains(wv.getModel())) {
                    area.remove(c);
                }
            }
        }

        gameController.getWires().removeAll(toRemove);

        area.revalidate();
        area.repaint();
        if (gameController.getHudController() != null) gameController.getHudController().refreshOnce();
    }


    public void retryStage() {
        if (currentDef == null) {
            throw new IllegalStateException("Cannot retry before a level has been started");
        }

        // 1) توقف شبیه‌سازی
        gameController.getSimulation().stop();

        // 2) سیم‌های مرحلهٔ جاری را بردار (سیم‌های مراحل قبل بمانند)
        purgeCurrentLevelWires();

        // 3) پاک‌سازی state گذرا قبل از بازسازی مرحله
        //    3-الف) پاک کردن همهٔ پکت‌های روی تمام سیم‌های باقی‌مانده (مراحل قبل)
        for (WireModel w : gameController.getWires()) {
            w.clearPackets();
        }
        //    3-ب) خالی کردن بافر تمام باکس‌های موجود (لیست boxes فعلیِ همین LevelCoreManager)
        if (boxes != null) {
            for (SystemBoxModel b : boxes) {
                b.clearBuffer();
            }
        }
        //    3-ج) پاک کردن تمام PacketView های باقی‌مانده از UI
        JPanel area = gameController.getGameView().getGameArea();
        java.awt.Component[] comps = area.getComponents();
        for (java.awt.Component c : comps) {
            if (c instanceof com.blueprinthell.view.PacketView) {
                area.remove(c);
            }
        }
        area.revalidate();
        area.repaint();

        // 4) شروع مجدد همان LevelDefinition (بازسازی کامل)
        startLevel(currentDef);
    }




    @Deprecated
    public void retryLevel(LevelDefinition def) {
        gameController.getSimulation().stop();
        purgeCurrentLevelWires();
        startLevel(def);
    }
}