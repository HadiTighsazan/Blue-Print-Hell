package com.blueprinthell.controller;

import com.blueprinthell.media.ResourceManager;
import com.blueprinthell.model.PacketLossModel;
import com.blueprinthell.model.PacketModel;
import com.blueprinthell.model.Updatable;
import com.blueprinthell.model.WireModel;

import javax.sound.sampled.Clip;
import java.util.ArrayList;
import java.util.List;

/**
 * Detects collisions between packets using a spatial-hash grid; increases noise, and removes
 * packets whose noise exceeds MAX_NOISE. Plays impact sound once per tick when a packet is lost.
 */
public class CollisionController implements Updatable {
    private final List<WireModel> wires;
    private final SpatialHashGrid<PacketModel> grid;
    private final PacketLossModel lossModel;

    /* ---- Tunables ---- */
    private static final int CELL_SIZE = 50;
    private static final double COLLISION_RADIUS = 20.0;
    private static final double NOISE_INCREMENT  = 0.5;
    private static final double MAX_NOISE        = 5.0;

    /* ---- Runtime Flags ---- */
    private boolean collisionsEnabled = true;
    private boolean impactWaveEnabled = true;

    public CollisionController(List<WireModel> wires, PacketLossModel lossModel) {
        this.wires     = wires;
        this.lossModel = lossModel;
        this.grid      = new SpatialHashGrid<>(CELL_SIZE);
    }

    @Override
    public void update(double dt) {
        if (collisionsEnabled) {
            performCollisionPass();
        }
        handleNoiseRemovalAndSound();
    }

    /* -------------------------------------------------- */
    private void performCollisionPass() {
        grid.clear();
        // Broad phase: hash all packets
        for (WireModel w : wires) {
            for (PacketModel p : w.getPackets()) {
                grid.insert(p.getCenterX(), p.getCenterY(), p);
            }
        }
        // Narrow phase: for each packet, test neighbors
        for (WireModel w : wires) {
            for (PacketModel p : new ArrayList<>(w.getPackets())) {
                if (p.getProgress() <= 0) continue; // ignore new attachments
                for (PacketModel other : grid.retrieve(p.getCenterX(), p.getCenterY())) {
                    if (other == p || other.getProgress() <= 0) continue;
                    if (p.getCurrentWire() == other.getCurrentWire()) continue;
                    double dx = p.getCenterX() - other.getCenterX();
                    double dy = p.getCenterY() - other.getCenterY();
                    if (Math.hypot(dx, dy) <= COLLISION_RADIUS && impactWaveEnabled) {
                        p.increaseNoise(NOISE_INCREMENT);
                        other.increaseNoise(NOISE_INCREMENT);
                    }
                }
            }
        }
    }

    private void handleNoiseRemovalAndSound() {
        boolean played = false;
        for (WireModel w : wires) {
            List<PacketModel> doomed = new ArrayList<>();
            for (PacketModel p : w.getPackets()) {
                if (p.getNoise() >= MAX_NOISE) doomed.add(p);
            }
            for (PacketModel p : doomed) {
                w.removePacket(p);
                lossModel.increment();
                played = true;
            }
        }
        if (played) playImpactSound();
    }

    private void playImpactSound() {
        try {
            Clip c = ResourceManager.INSTANCE.getClip("impact_thud.wav");
            c.stop();
            c.setFramePosition(0);
            c.start();
        } catch (Exception ignored) { }
    }

    /* ---- Public control flags exposed for power‑ups ---- */
    public void pauseCollisions() { this.collisionsEnabled = false; }
    public void resumeCollisions() { this.collisionsEnabled = true; }
    public void setImpactWaveEnabled(boolean enabled) { this.impactWaveEnabled = enabled; }
}
