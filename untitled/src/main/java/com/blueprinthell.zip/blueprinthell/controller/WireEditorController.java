package com.blueprinthell.controller;

import com.blueprinthell.model.WireModel;
import com.blueprinthell.model.WirePath;
import com.blueprinthell.view.SystemBoxView;
import com.blueprinthell.view.WireView;
import com.blueprinthell.model.CoinModel;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * Controller that enables the player to add or move up‑to **three** intermediate control‑points
 * ("bends") on a selected wire.  A bend costs one coin the first time it is created; further
 * drags of the same bend are free.  The controller also prevents a bend from being dragged such
 * that any segment of the poly‑line would intersect a {@link SystemBoxView} rectangle.
 * <p>
 * Usage pattern (called by {@code GameController} once a wire is created):
 * <pre>
 *   new WireEditorController(gameArea, wireModel, wireView,
 *                            systemViews, coinModel, onNetworkChanged);
 * </pre>
 */
@SuppressWarnings("serial")
public class WireEditorController {

    // --- constants ----------------------------------------------------------
    private static final int MAX_BENDS     = 3;
    private static final int HANDLE_RADIUS = 6;   // px for hit‑testing a control‑point
    private static final int CLICK_DIST    = 8;   // px from segment to add a new point
    private static final int BEND_COST     = 1;   // coins

    // --- state --------------------------------------------------------------
    private final JPanel          canvas;
    private final WireModel       wire;
    private final WireView        wireView;
    private final List<SystemBoxView> obstacles;
    private final CoinModel       coins;
    private final Runnable        networkChanged;

    private int  dragIndex = -1; // index of bend currently being dragged (‑1 = none)

    // --- ctor ---------------------------------------------------------------
    public WireEditorController(JPanel canvas,
                                WireModel wire,
                                WireView wireView,
                                List<SystemBoxView> systemBoxes,
                                CoinModel coins,
                                Runnable networkChanged) {
        this.canvas          = canvas;
        this.wire            = wire;
        this.wireView        = wireView;
        this.obstacles       = systemBoxes;
        this.coins           = coins;
        this.networkChanged  = networkChanged;

        installMouseHandlers();
    }

    // -----------------------------------------------------------------------
    private void installMouseHandlers() {
        MouseAdapter ma = new MouseAdapter() {
            @Override public void mousePressed(MouseEvent e) { selectOrAddHandle(e.getPoint()); }
            @Override public void mouseDragged(MouseEvent e) { dragHandle(e.getPoint()); }
            @Override public void mouseReleased(MouseEvent e) { dragIndex = -1; }
        };
        canvas.addMouseListener(ma);
        canvas.addMouseMotionListener(ma);
    }

    // Try to pick an existing handle, otherwise add a new one if allowed.
    private void selectOrAddHandle(Point click) {
        WirePath path = wire.getPath();
        List<Point> cps = path.controlPoints();

        // (1) check existing handles
        for (int i = 1; i < cps.size() - 1; i++) { // skip endpoints
            Point p = cps.get(i);
            if (p.distance(click) <= HANDLE_RADIUS) {
                dragIndex = i;
                return;
            }
        }
        // (2) try to insert new handle
        if (cps.size() - 2 >= MAX_BENDS) return; // limit reached

        int segIdx = nearestSegmentIndex(cps, click);
        if (segIdx >= 0) {
            if (coins.getCoins() < BEND_COST) {
                Toolkit.getDefaultToolkit().beep();
                return; // insufficient funds
            }
            coins.spend(BEND_COST);
            cps.add(segIdx + 1, click);
            dragIndex = segIdx + 1;
            commitPath(cps);
        }
    }

    // Drag currently selected handle, enforcing obstacle / max length checks.
    private void dragHandle(Point p) {
        if (dragIndex < 0) return;
        WirePath path = wire.getPath();
        List<Point> cps = path.controlPoints();
        cps.set(dragIndex, p);

        // Reject move if any segment now intersects an obstacle.
        if (intersectsAnyObstacle(cps)) return; // ignore move

        commitPath(cps);
    }

    private void commitPath(List<Point> cps) {
        wire.setPath(new WirePath(cps));
        wireView.repaint();
        if (networkChanged != null) networkChanged.run();
    }

    /* ---------- helpers --------------------------------------------------- */
    private static int nearestSegmentIndex(List<Point> cps, Point click) {
        double minDist = CLICK_DIST;
        int    idx     = -1;
        for (int i = 0; i < cps.size() - 1; i++) {
            Point a = cps.get(i);
            Point b = cps.get(i + 1);
            double d = distPointToSegment(click, a, b);
            if (d < minDist) { minDist = d; idx = i; }
        }
        return idx;
    }

    // distance from point C to segment AB
    private static double distPointToSegment(Point c, Point a, Point b) {
        double vx = b.x - a.x, vy = b.y - a.y;
        double wx = c.x - a.x, wy = c.y - a.y;
        double c1 = vx * wx + vy * wy;
        if (c1 <= 0) return a.distance(c);
        double c2 = vx * vx + vy * vy;
        if (c2 <= c1) return b.distance(c);
        double t = c1 / c2;
        double px = a.x + t * vx;
        double py = a.y + t * vy;
        return Point.distance(c.x, c.y, px, py);
    }

    private boolean intersectsAnyObstacle(List<Point> cps) {
        for (int i = 0; i < cps.size() - 1; i++) {
            Point a = cps.get(i);
            Point b = cps.get(i + 1);
            for (SystemBoxView box : obstacles) {
                if (segmentIntersectsRect(a, b, box.getBounds())) return true;
            }
        }
        return false;
    }

    private static boolean segmentIntersectsRect(Point p1, Point p2, Rectangle r) {
        // Cohen–Sutherland trivial accept/reject via Java's Line2D helper
        return new java.awt.geom.Line2D.Double(p1, p2).intersects(r);
    }
}
