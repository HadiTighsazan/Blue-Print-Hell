package com.blueprinthell.controller;

import com.blueprinthell.config.Config;
import com.blueprinthell.model.*;
import com.blueprinthell.model.CoinModel;
import com.blueprinthell.view.HudView;
import com.blueprinthell.view.SystemBoxView;
import com.blueprinthell.view.screens.GameScreenView;
import com.blueprinthell.level.LevelManager;
import com.blueprinthell.level.LevelCompletionDetector;
import com.blueprinthell.level.LevelDefinition;
import com.blueprinthell.level.LevelGenerator;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.util.List;

public class GameController implements NetworkController {
    private final TimelineController timelineController;
    private final WireUsageModel usageModel;
    private final PacketLossModel lossModel;
    private final SnapshotManager snapshotManager;
    private PacketRenderController packetRenderController;

    private final SimulationController simulation;
    private final ScoreModel scoreModel;
    private final CoinModel coinModel;
    private final HudView hudView;
    private final GameScreenView gameView;

    // Collision controller kept as field so UI (ShopController) can toggle its behaviour
    private final CollisionController collisionController;

    private final ScreenController screenController; // اضافه شده

    private List<SystemBoxModel> boxes;
    private final List<WireModel> wires = new ArrayList<>();
    private final Map<WireModel, SystemBoxModel> destMap = new HashMap<>();
    private boolean collisionRegistered = false;
    private boolean completionRegistered = false;
    private LevelManager levelManager;

    public GameController(ScreenController screenController) {
        this.screenController = screenController; // اضافه شده

        // initialize models
        this.usageModel = new WireUsageModel(1000.0);
        this.lossModel = new PacketLossModel();
        this.snapshotManager = new SnapshotManager();

        // initialize simulation and timeline
        this.simulation = new SimulationController(60);
        this.timelineController = new TimelineController(this, 1000);
        simulation.setTimelineController(timelineController);

        // initialize score, HUD, and game view
        this.scoreModel = new ScoreModel();
        this.coinModel = new CoinModel();
        this.hudView = new HudView(0, 0, 800, 50);
        this.gameView = new GameScreenView(hudView);
        screenController.registerGameScreen(gameView);

        // collision controller needs reference to wires list (shared) & loss model
        this.collisionController = new CollisionController(wires, lossModel);
    }

    /**
     * Sets up and starts the specified level.
     */
    public void startLevel(LevelDefinition def) {
        simulation.stop();
        scoreModel.reset();
        wires.clear();
        destMap.clear();
        lossModel.reset();
        snapshotManager.clear();
        timelineController.resume();
        usageModel.reset(def.totalWireLength());

        boxes = new ArrayList<>();
        for (LevelDefinition.BoxSpec spec : def.boxes()) {
            SystemBoxModel box = new SystemBoxModel(
                    spec.x(), spec.y(), spec.width(), spec.height(),
                    spec.inShapes(), spec.outShapes()
            );
            boxes.add(box);
        }

        gameView.reset(boxes, wires);

        for (Component c : gameView.getGameArea().getComponents()) {
            if (c instanceof SystemBoxView sbv) {
                new SystemBoxDragController(sbv.getModel(), sbv, wires, usageModel);
            }
        }

        WireCreationController creator =
                new WireCreationController(gameView, simulation, boxes, wires, destMap, usageModel);
        new WireRemovalController(gameView, wires, destMap, creator, usageModel);

        List<SystemBoxModel> sources = new ArrayList<>();
        SystemBoxModel sinkBox = null;
        for (int i = 0; i < def.boxes().size(); i++) {
            var bs = def.boxes().get(i);
            var m  = boxes.get(i);
            if (bs.isSource()) sources.add(m);
            if (bs.isSink())   sinkBox = m;
        }

        PacketProducerController producer =
                new PacketProducerController(sources, wires, destMap, Config.DEFAULT_PACKET_SPEED);
        simulation.register(producer);

        if (sinkBox != null) {
            simulation.register(new PacketConsumerController(sinkBox, scoreModel, coinModel));
        }

        boxes.stream()
                .filter(b -> !b.getInPorts().isEmpty() && !b.getOutPorts().isEmpty())
                .forEach(b -> simulation.register(new PacketRouterController(b, wires, destMap)));

        simulation.register(new PacketDispatcherController(wires, destMap, coinModel));

        packetRenderController = new PacketRenderController(gameView.getGameArea(), wires);
        simulation.register(packetRenderController);

        // ----- Loss monitor: GameOver when PacketLoss > 50% -----
        int maxPackets = 0;
        for (SystemBoxModel src : sources) {
            maxPackets += src.getOutPorts().size() * Config.PACKETS_PER_PORT;
        }
        LossMonitorController lossMon = new LossMonitorController(
                lossModel,
                maxPackets,
                producer,
                0.5,
                simulation,
                screenController,
                () -> startLevel(levelManager != null
                        ? levelManager.getLevelIndex() + 1
                        : 1)
        );
        simulation.register(lossMon);

        if (!collisionRegistered) {
            simulation.register(collisionController);
            collisionRegistered = true;
        }

        SnapshotController snapCtrl = new SnapshotController(
                boxes, wires, scoreModel, usageModel, lossModel, snapshotManager
        );
        simulation.register(snapCtrl);
        snapCtrl.update(0);

        HudController hudCtrl = new HudController(
                scoreModel, usageModel, lossModel, coinModel, levelManager, hudView
        );
        simulation.register(hudCtrl);
        hudCtrl.refreshOnce();

        // ----- Level completion detector -----
        if (levelManager != null && !completionRegistered) {
            simulation.register(new LevelCompletionDetector(wires, lossModel, levelManager, 50));
            completionRegistered = true;
        }

        gameView.setTemporalNavigationListener(dir -> {
            simulation.stop();
            if (dir < 0) {
                timelineController.scrubTo(timelineController.getCurrentOffset() + 1);
            } else if (dir > 0) {
                timelineController.scrubTo(timelineController.getCurrentOffset() - 1);
            }
            packetRenderController.refreshAll();
            hudView.setScore(scoreModel.getScore());
        });

        // ----- HUD buttons -----
        hudView.addStartListener(e -> {
            producer.startProduction();
            hudView.getStartButton().setEnabled(false);
            if (!timelineController.isPlaying()) {
                timelineController.resume();
            }
            simulation.start();
        });

        hudView.addToggleListener(e -> {
            if (simulation.isRunning()) {
                simulation.stop();
                producer.stopProduction();
                timelineController.pause();
                hudView.setToggleText("Resume");
            } else {
                producer.startProduction();
                timelineController.resume();
                simulation.start();
                hudView.setToggleText("Pause");
            }
        });
    }

    public void startLevel(int level) {
        if (level == 1) {
            startLevel(LevelGenerator.firstLevel());
        } else {
            LevelDefinition def = LevelGenerator.firstLevel();
            for (int i = 1; i < level; i++) {
                def = LevelGenerator.nextLevel(def);
            }
            startLevel(def);
        }
    }

    public GameScreenView getGameView() { return gameView; }
    public SimulationController getSimulation() { return simulation; }
    public ScoreModel getScoreModel() { return scoreModel; }
    public CollisionController getCollisionController() { return collisionController; }
    public PacketLossModel getLossModel() { return lossModel; }

    @Override
    public NetworkSnapshot captureSnapshot() {
        List<NetworkSnapshot.SystemBoxState> bs = new ArrayList<>();
        for (SystemBoxModel b : boxes) {
            bs.add(new NetworkSnapshot.SystemBoxState(
                    b.getX(), b.getY(), b.getWidth(), b.getHeight(),
                    b.getInShapes(), b.getOutShapes()
            ));
        }
        List<NetworkSnapshot.WireState> ws = new ArrayList<>();
        for (WireModel w : wires) {
            List<NetworkSnapshot.PacketState> ps = new ArrayList<>();
            for (PacketModel p : w.getPackets()) {
                ps.add(new NetworkSnapshot.PacketState(
                        p.getProgress(), p.getNoise(), p.getType()
                ));
            }
            ws.add(new NetworkSnapshot.WireState(
                    w.getSrcPort().getCenterX(), w.getSrcPort().getCenterY(),
                    w.getDstPort().getCenterX(), w.getDstPort().getCenterY(), ps
            ));
        }
        return new NetworkSnapshot(scoreModel.getScore(), lossModel.getLostCount(), bs, ws);
    }

    @Override
    public void restoreState(NetworkSnapshot snap) {
        applySnapshot(snap);
    }

    private void applySnapshot(NetworkSnapshot snap) {
        scoreModel.reset();
        scoreModel.addPoints(snap.score());
        lossModel.reset();
        for (int i = 0; i < snap.packetLoss(); i++) {
            lossModel.increment();
        }
        List<NetworkSnapshot.SystemBoxState> boxStates = snap.boxStates();
        for (int i = 0; i < boxes.size() && i < boxStates.size(); i++) {
            var st  = boxStates.get(i);
            var box = boxes.get(i);
            box.setX(st.x());
            box.setY(st.y());
        }
        List<NetworkSnapshot.WireState> wireStates = snap.wireStates();
        for (int i = 0; i < wires.size() && i < wireStates.size(); i++) {
            var wire  = wires.get(i);
            var state = wireStates.get(i);
            wire.clearPackets();
            for (var ps : state.packets()) {
                var p = new PacketModel(ps.type(), Config.DEFAULT_PACKET_SPEED);
                p.resetNoise();
                p.increaseNoise(ps.noise());
                wire.attachPacket(p, ps.progress());
            }
        }
        gameView.reset(boxes, wires);
        packetRenderController.refreshAll();
        hudView.setScore(scoreModel.getScore());
    }

    public List<WireModel> getWires() {
        return wires;
    }

    /** Injects the LevelManager so this controller can notify success. */
    public void setLevelManager(LevelManager manager) {
        this.levelManager = manager;
    }

    public CoinModel getCoinModel() {
        return coinModel;
    }
}
