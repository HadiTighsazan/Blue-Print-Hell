package com.blueprinthell.ui;


public interface LevelSelectListener {
    void onLevelSelected(int levelIndex);
    void onBack();
}