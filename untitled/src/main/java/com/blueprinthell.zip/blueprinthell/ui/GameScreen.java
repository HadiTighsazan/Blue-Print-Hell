// GameScreen.java
package com.blueprinthell.ui;

import com.blueprinthell.engine.NetworkController;
import com.blueprinthell.engine.TimelineController;
import com.blueprinthell.engine.SnapshotManager;
import com.blueprinthell.engine.NetworkSnapshot;
import com.blueprinthell.model.Packet;
import com.blueprinthell.model.PacketType;
import com.blueprinthell.model.Port;
import com.blueprinthell.model.SystemBox;
import com.blueprinthell.model.Wire;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.Arrays;
import java.util.List;

/**
 * نمای اصلی بازی: سیستم‌ها، سیم‌ها، پیش‌نمایش، HUD و کنترل زمان.
 */
public class GameScreen extends JLayeredPane {
    private List<SystemBox> systems;
    private List<Wire> wires;
    private NetworkController networkController;

    private InputManager inputManager;
    private WirePreviewLayer previewLayer;

    // HUD components
    private JPanel hudPanel;
    private JLabel lblWire, lblCoins, lblLoss;
    private JButton btnStart, btnShop;
    private JSlider sliderTime;
    private JButton btnPausePlay;
    private Timer gameTimer;

    // Timeline/Snapshot
    private TimelineController timelineCtrl;
    private SnapshotManager snapMgr;
    private int timelineCapacity;

    public GameScreen() {
        setLayout(null);
    }

    /**
     * بارگذاری سطح مشخص: سیستم‌ها و سیم‌ها و HUD و کنترلرهای زمان
     */
    public void loadLevel(int levelIndex) {
        removeAll();
        if (gameTimer != null && gameTimer.isRunning()) {
            gameTimer.stop();
        }

        // ۱) تعریف سیستم‌ها و سیم‌ها بر اساس levelIndex
        if (levelIndex == 1) {
            systems = Arrays.asList(
                    new SystemBox(100, 200, 120, 80, 0, 1),
                    new SystemBox(350, 200, 120, 80, 1, 1),
                    new SystemBox(600, 200, 120, 80, 1, 0)
            );
            wires = Arrays.asList(
                    new Wire(systems.get(0).getOutPorts().get(0),
                            systems.get(1).getInPorts().get(0)),
                    new Wire(systems.get(1).getOutPorts().get(0),
                            systems.get(2).getInPorts().get(0))
            );
        } else {
            systems = Arrays.asList(
                    new SystemBox(80,  80, 100, 60, 0, 1),
                    new SystemBox(280, 80, 100, 60, 1, 1),
                    new SystemBox(480, 80, 100, 60, 1, 1),
                    new SystemBox(80,  280,100, 60, 1, 1),
                    new SystemBox(280, 280,100, 60, 1, 1),
                    new SystemBox(480, 280,100, 60, 1, 0)
            );
            wires = Arrays.asList(
                    new Wire(systems.get(0).getOutPorts().get(0),
                            systems.get(1).getInPorts().get(0)),
                    new Wire(systems.get(1).getOutPorts().get(0),
                            systems.get(2).getInPorts().get(0)),
                    new Wire(systems.get(0).getOutPorts().get(0),
                            systems.get(3).getInPorts().get(0)),
                    new Wire(systems.get(3).getOutPorts().get(0),
                            systems.get(4).getInPorts().get(0)),
                    new Wire(systems.get(4).getOutPorts().get(0),
                            systems.get(5).getInPorts().get(0))
            );
        }

        // ۲) راه‌اندازی NetworkController و Timeline/Snapshot
        timelineCapacity    = 5 * 60; // ۵ ثانیه در ۶۰fps
        networkController   = new NetworkController(wires, systems, 1500);
        timelineCtrl        = new TimelineController(networkController, timelineCapacity);
        snapMgr             = new SnapshotManager(timelineCapacity);

        // ۳) افزودن سیستم‌ها و سیم‌ها به لایهٔ پیش‌فرض
        systems.forEach(s -> add(s, JLayeredPane.DEFAULT_LAYER));
        wires.forEach(w   -> add(w, JLayeredPane.DEFAULT_LAYER));

        // ۴) تنظیم InputManager و پیش‌نمایش سیم
        inputManager   = new InputManager(networkController);
        previewLayer   = new WirePreviewLayer(inputManager);
        previewLayer.setBounds(0, 0, getWidth(), getHeight());
        add(previewLayer, JLayeredPane.DRAG_LAYER);

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                int w = getWidth(), h = getHeight();
                // ۱) previewLayer همیشه کل صفحه را بپوشاند
                previewLayer.setBounds(0, 0, w, h);
                // ۲) سیم‌ها هم full-screen باشند (تا در هر حالتی درست رسم شوند)
                for (Wire wire : wires) {
                    wire.setBounds(0, 0, w, h);
                }
                // ۳) HUD در بالای صفحه قرار گیرد
                hudPanel.setBounds(0, 0, w, hudPanel.getHeight());
                previewLayer.setEnabled(true);

            }
        });



        inputManager.registerHitContainer(this);
        inputManager.registerEventContainer(previewLayer);
        systems.forEach(s -> s.getOutPorts().forEach(inputManager::registerPort));
        systems.forEach(s -> s.getInPorts().forEach(inputManager::registerPort));

        // ۵) ساخت و افزودن HUD
        initHUD();

        revalidate();
        repaint();
    }

    private void initHUD() {
        if (hudPanel != null) remove(hudPanel);

        hudPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        hudPanel.setBackground(new Color(0, 0, 0, 160));
        hudPanel.setBounds(0, 0, getWidth(), 40);

        lblWire      = new JLabel();
        lblCoins     = new JLabel();
        lblLoss      = new JLabel();
        btnStart     = new JButton("Start");
        btnShop      = new JButton("Shop");
        sliderTime   = new JSlider(0, timelineCapacity - 1, 0);
        btnPausePlay = new JButton("Pause");

        btnStart.addActionListener(this::onStart);
        btnShop.addActionListener(e -> openShop());

        sliderTime.setPreferredSize(new Dimension(200, 20));
        sliderTime.addChangeListener(e -> {
            if (!sliderTime.getValueIsAdjusting() && !timelineCtrl.isPlaying()) {
                NetworkSnapshot snap =
                        snapMgr.getSnapshotFramesAgo(sliderTime.getValue());
                networkController.restoreState(snap);
                repaint();
            }
        });

        btnPausePlay.addActionListener(e -> {
            if (timelineCtrl.isPlaying()) {
                timelineCtrl.pause();
                btnPausePlay.setText("Play");
            } else {
                NetworkSnapshot snap =
                        snapMgr.getSnapshotFramesAgo(sliderTime.getValue());
                networkController.restoreState(snap);
                timelineCtrl.resume();
                sliderTime.setValue(0);
                btnPausePlay.setText("Pause");
            }
        });

        hudPanel.add(lblWire);
        hudPanel.add(lblCoins);
        hudPanel.add(lblLoss);
        hudPanel.add(btnStart);
        hudPanel.add(btnShop);
        hudPanel.add(sliderTime);
        hudPanel.add(btnPausePlay);

        add(hudPanel, JLayeredPane.PALETTE_LAYER);
        updateHUD();
    }

    private void updateHUD() {
        lblWire.setText("Wire Left: " +
                String.format("%.0f", networkController.getRemainingWireLength()));
        lblCoins.setText("Coins: " + networkController.getCoins());
        lblLoss.setText("Loss: " + networkController.getPacketLoss());
    }

    private void onStart(ActionEvent e) {
        // تولید اولیه پکت‌ها از سیستم‌های بدون inPorts
        systems.stream()
                .filter(s -> s.getInPorts().isEmpty())
                .forEach(s -> {
                    Port out = s.getOutPorts().get(0);
                    Wire w = wires.stream()
                            .filter(x -> x.getSrcPort() == out).findFirst().orElse(null);
                    if (w != null) {
                        Packet p = new Packet(PacketType.SQUARE, 100);
                        w.attachPacket(p, 0.0);
                        add(p, JLayeredPane.DEFAULT_LAYER);
                    }
                });

        if (gameTimer != null) gameTimer.stop();
        gameTimer = new Timer(16, ev -> {
            double dt = 0.016;
            if (timelineCtrl.isPlaying()) {
                networkController.tick(dt);
                timelineCtrl.recordFrame();
                if (sliderTime.getValue() != 0) sliderTime.setValue(0);
            } else {
                NetworkSnapshot snap =
                        snapMgr.getSnapshotFramesAgo(sliderTime.getValue());
                networkController.restoreState(snap);
            }
            updateHUD();
            repaint();
        });
        gameTimer.start();
        btnStart.setEnabled(false);
    }

    private void openShop() {
        ShopDialog dlg =
                new ShopDialog(SwingUtilities.getWindowAncestor(this), networkController);
        dlg.setVisible(true);
        updateHUD();
    }
}
