package com.blueprinthell.view.screens;

import javax.swing.*;
import java.awt.*;

/**
 * Settings menu screen with volume slider, *single* key‑binding button, and Back button.
 */
public class SettingsMenuView extends JPanel {
    /* --------- Components exposed to controller --------- */
    public final JButton backButton = new JButton("Back");
    public final JSlider volumeSlider = new JSlider(0, 100, 50);

    // Single button displaying both keys (Back | Forward)
    public final JButton keyBindingButton = new JButton();

    public SettingsMenuView() {
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        setBackground(Color.GRAY);
        setPreferredSize(new Dimension(800, 600));

        /* ---------- Volume section ---------- */
        add(Box.createVerticalGlue());
        add(createLabel("Volume:"));
        add(createSliderPanel(volumeSlider));
        add(Box.createRigidArea(new Dimension(0, 30)));

        /* ---------- Key binding section ---------- */
        add(createLabel("Key Bindings:"));
        add(Box.createRigidArea(new Dimension(0, 10)));
        add(createButtonPanel(keyBindingButton));
        add(Box.createRigidArea(new Dimension(0, 30)));

        /* ---------- Back button ---------- */
        add(createButtonPanel(backButton));
        add(Box.createVerticalGlue());
    }

    /* ---------------- Helper UI builders ---------------- */
    private Component createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setForeground(Color.WHITE);
        label.setFont(label.getFont().deriveFont(Font.BOLD));
        return label;
    }

    private Component createSliderPanel(JSlider slider) {
        JPanel panel = new JPanel();
        panel.setOpaque(false);
        panel.add(slider);
        return panel;
    }

    private JPanel createButtonPanel(JButton button) {
        JPanel p = new JPanel();
        p.setOpaque(false);
        p.add(button);
        return p;
    }
}
