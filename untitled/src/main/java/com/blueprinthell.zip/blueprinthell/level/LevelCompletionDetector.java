package com.blueprinthell.level;

import com.blueprinthell.model.PacketLossModel;
import com.blueprinthell.model.Updatable;
import com.blueprinthell.model.WireModel;

import java.util.List;

/**
 * Monitors packet flow to determine when a level is successfully completed.
 * Criteria (first pass):
 *  • هیچ پکتی روی هیچ سیم نباشد (شبکه تخلیه شده باشد)
 *  • Packet‑Loss کمتر از ۵۰٪ (یا هر آستانهٔ دلخواه)
 *  • سپس به LevelManager اعلام موفقیت می‌کند.
 */
public class LevelCompletionDetector implements Updatable {
    private final List<WireModel> wires;
    private final PacketLossModel lossModel;
    private final LevelManager levelManager;
    private final double lossThreshold;

    private boolean reported = false;

    public LevelCompletionDetector(List<WireModel> wires,
                                   PacketLossModel lossModel,
                                   LevelManager levelManager,
                                   double lossThreshold) {
        this.wires = wires;
        this.lossModel = lossModel;
        this.levelManager = levelManager;
        this.lossThreshold = lossThreshold;
    }

    @Override
    public void update(double dt) {
        if (reported) return;
        // شرط ۱: هیچ پکتی در شبکه نباشد
        boolean empty = wires.stream().allMatch(w -> w.getPackets().isEmpty());
        // شرط ۲: میزان از دست رفتن پکت‌ها کمتر از آستانه
        boolean okLoss = lossModel.getLostCount() < lossThreshold;
        if (empty && okLoss) {
            reported = true;
            javax.swing.SwingUtilities.invokeLater(levelManager::onLevelSuccess);
        }
    }
}
