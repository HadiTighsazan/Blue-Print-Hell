package com.blueprinthell.level;

import com.blueprinthell.controller.GameController;

/**
 * Drives progression through sequential levels using {@link LevelGenerator}. GameController must expose
 * startLevel(LevelDefinition) that consumes the blueprint and instantiates runtime models.
 */
public class LevelManager {
    private final GameController gameController;
    private LevelDefinition current;
    private int levelIndex = -1;

    public LevelManager(GameController gc) {
        this.gameController = gc;
    }

    /** Starts a new game from level 0. */
    public void startGame() {
        levelIndex = 0;
        current = LevelGenerator.firstLevel();
        gameController.startLevel(current);
    }

    /** Should be called by GameController when player beats the current level. */
    public void onLevelSuccess() {
        levelIndex++;
        current = LevelGenerator.nextLevel(current);
        gameController.startLevel(current);
    }

    public int getLevelIndex() { return levelIndex; }
    public LevelDefinition getCurrentDefinition() { return current; }
}
