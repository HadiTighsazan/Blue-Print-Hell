package com.blueprinthell.level;

import com.blueprinthell.model.PortShape;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Generates LevelDefinition instances following the progressive ruleset:
 *  - Level 0: single Source ➜ single Sink
 *  - Each next level converts previous Sink ➜ regular box (same inputs, new random outputs)
 *    and appends (1) a new Sink, (2) an intermediary box that forces at least
 *    a two‑hop route. Wire length budget is recalculated as minPath + 10%.
 */
public final class LevelGenerator {

    private static final int BOX_W = 80;
    private static final int BOX_H = 80;
    private static final Random RND = new Random();

    private LevelGenerator() {}

    /** Produces the first level (index 0). */
    public static LevelDefinition firstLevel() {
        List<LevelDefinition.BoxSpec> boxes = new ArrayList<>();
        // Source on left
        boxes.add(new LevelDefinition.BoxSpec(
                50, 100, BOX_W, BOX_H,
                List.of(),
                List.of(PortShape.SQUARE),
                true, false));
        // Sink on right
        boxes.add(new LevelDefinition.BoxSpec(
                350, 100, BOX_W, BOX_H,
                List.of(PortShape.SQUARE),
                List.of(),
                false, true));
        double budget = 500; // base wire length
        return new LevelDefinition(boxes, budget);
    }

    /**
     * Generates the next level based on the previous definition.
     * @param prev previous level blueprint
     * @return new LevelDefinition following ruleset
     */
    public static LevelDefinition nextLevel(LevelDefinition prev) {
        List<LevelDefinition.BoxSpec> prevBoxes = prev.boxes();
        List<LevelDefinition.BoxSpec> nextBoxes = new ArrayList<>();

        LevelDefinition.BoxSpec oldSink = null;
        for (LevelDefinition.BoxSpec b : prevBoxes) {
            if (b.isSink()) oldSink = b;
            nextBoxes.add(copyBox(b, false));
        }
        if (oldSink == null) throw new IllegalStateException("Previous level had no sink");

        /* ----------- balanced port generation ----------- */
        int totalPorts = 3 + RND.nextInt(3); // 3‑5
        List<PortShape> portShapes = new ArrayList<>();
        for (int i = 0; i < totalPorts; i++) portShapes.add(randomShape());
        // inputs are a shuffled clone
        List<PortShape> inputShapes = new ArrayList<>(portShapes);
        Collections.shuffle(inputShapes, RND);

        // Split outputs between transformed box و intermediary
        int outForOld = 1 + RND.nextInt(Math.max(1, totalPorts - 1));
        List<PortShape> outsOldSink = new ArrayList<>(portShapes.subList(0, outForOld));
        List<PortShape> outsInter   = new ArrayList<>(portShapes.subList(outForOld, totalPorts));
        if (outsInter.isEmpty()) outsInter.add(randomShape());

        // Split inputs: حداقل 1 ورودی برای جعبهٔ واسط
        int inForInter = Math.min(1, inputShapes.size() - 1);
        List<PortShape> insInter = new ArrayList<>(inputShapes.subList(0, inForInter));
        List<PortShape> insSink  = new ArrayList<>(inputShapes.subList(inForInter, inputShapes.size()));
        if (insSink.isEmpty()) insSink.add(randomShape());

        /* ----------- build boxes ----------- */
        LevelDefinition.BoxSpec transformed = new LevelDefinition.BoxSpec(
                oldSink.id(), oldSink.x(), oldSink.y(), oldSink.width(), oldSink.height(),
                oldSink.inShapes(), outsOldSink, false, false);
        LevelDefinition.BoxSpec finalOldSink = oldSink;
        nextBoxes.replaceAll(b -> b.id().equals(finalOldSink.id()) ? transformed : b);

        // intermediary box
        int ix = oldSink.x() + 150;
        int iy = oldSink.y() + (RND.nextBoolean() ? 120 : -120);
        nextBoxes.add(new LevelDefinition.BoxSpec(ix, iy, BOX_W, BOX_H,
                insInter.isEmpty() ? List.of(randomShape()) : insInter,
                outsInter, false, false));

        // sink box
        int sx = oldSink.x() + 300;
        int sy = oldSink.y();
        nextBoxes.add(new LevelDefinition.BoxSpec(sx, sy, BOX_W, BOX_H,
                insSink, List.of(), false, true));

        double budget = prev.totalWireLength() * 1.1; // +10%
        return new LevelDefinition(nextBoxes, budget);
    }

    /* ---------------- Helpers ---------------- */
    private static LevelDefinition.BoxSpec copyBox(LevelDefinition.BoxSpec src, boolean keepSinkFlag) {
        return new LevelDefinition.BoxSpec(src.id(), src.x(), src.y(), src.width(), src.height(),
                src.inShapes(), src.outShapes(), src.isSource(), keepSinkFlag && src.isSink());
    }

    private static List<PortShape> randomOutputs() {
        // at least 2 outputs, mix shapes
        PortShape s1 = randomShape();
        PortShape s2 = (s1 == PortShape.SQUARE ? PortShape.TRIANGLE : PortShape.SQUARE);
        return RND.nextBoolean() ? List.of(s1, s2) : List.of(s1, s2, randomShape());
    }

    private static PortShape randomShape() {
        return RND.nextBoolean() ? PortShape.SQUARE : PortShape.TRIANGLE;
    }
}
