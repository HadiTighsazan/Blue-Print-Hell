package com.blueprinthell.server.pvp;

import com.blueprinthell.controller.GameController;
import com.blueprinthell.level.LevelRegistry;
import com.blueprinthell.shared.protocol.NetworkProtocol.Message;
import com.blueprinthell.snapshot.NetworkSnapshot;

/**
 * Manages the server-side simulation for a single PvP match.
 * It holds two separate, headless instances of the main GameController,
 * one for each player, ensuring a full-featured simulation.
 */
public class ServerGameSession {

    private final String matchId;
    private final GameController gameControllerP1;
    private final GameController gameControllerP2;

    public ServerGameSession(String matchId) {
        this.matchId = matchId;

        // Create two independent, headless GameController instances
        this.gameControllerP1 = new GameController(true); // isHeadless = true
        this.gameControllerP2 = new GameController(true); // isHeadless = true

        // Load a default level definition for both (e.g., Level 1)
        // In the future, this could be a specific PvP map.
        gameControllerP1.startLevel(LevelRegistry.getLevel(1).getDefinition());
        gameControllerP2.startLevel(LevelRegistry.getLevel(1).getDefinition());
    }

    /**
     * Executes a single simulation tick for both players.
     * @param dt Delta time in seconds.
     */
    public void tick(double dt) {
        // This call is now correct because SimulationController.update(dt) is public.
        gameControllerP1.getSimulation().update(dt);
        gameControllerP2.getSimulation().update(dt);
    }

    /**
     * Applies a player's action to their corresponding GameController.
     * This is where player inputs from the network will be processed.
     *
     * @param playerSide The side of the player (1 or 2).
     * @param action The action message received from the client.
     */
    public void applyPlayerAction(int playerSide, Message action) {
        GameController targetController = (playerSide == 1) ? gameControllerP1 : gameControllerP2;

        // TODO: Implement the logic to handle different PlayerAction_* messages.
        // For now, this is a placeholder.
        // Example:
        // if (action instanceof PlayerAction_CreateWire createWireAction) {
        //     // Find ports and create wire in targetController's model
        // }
    }

    /**
     * Captures the full state of both players' simulations.
     * @return An array of two NetworkSnapshots, [player1_snapshot, player2_snapshot].
     */
    public NetworkSnapshot[] captureSnapshots() {
        return new NetworkSnapshot[]{
                gameControllerP1.captureSnapshot(),
                gameControllerP2.captureSnapshot()
        };
    }

    /**
     * Starts the simulation for both players.
     */
    public void startSimulations() {
        gameControllerP1.getSimulation().start();
        gameControllerP2.getSimulation().start();
    }

    /**
     * Stops the simulation for both players.
     */
    public void stopSimulations() {
        gameControllerP1.getSimulation().stop();
        gameControllerP2.getSimulation().stop();
    }
}