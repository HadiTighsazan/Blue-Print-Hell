package com.blueprinthell.server.pvp;

import com.blueprinthell.server.pvp.PvPMatchManager.QueuedPlayer;
import com.blueprinthell.shared.protocol.NetworkProtocol.*;
import com.blueprinthell.snapshot.NetworkSnapshot;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Manages the state machine and lifecycle of a PvP match session.
 * It delegates the actual game simulation to a ServerGameSession instance.
 */
public class PvPGameSession {

    private static final int BUILD_TIME_SECONDS = 30;
    private static final int EXTEND_TIME_SECONDS = 10;
    private static final int MAX_EXTENDS = 3;
    private static final int COUNTDOWN_SECONDS = 3;
    private static final int MATCH_DURATION_MINUTES = 3;

    private final String matchId;
    private final QueuedPlayer player1;
    private final QueuedPlayer player2;
    private final PvPMatchManager.MatchEventHandler eventHandler;

    private volatile Phase currentPhase = Phase.BUILD;
    private final AtomicInteger buildTimer = new AtomicInteger(BUILD_TIME_SECONDS);
    private final AtomicInteger extendStage = new AtomicInteger(0);
    private final AtomicBoolean p1Ready = new AtomicBoolean(false);
    private final AtomicBoolean p2Ready = new AtomicBoolean(false);

    private SubmitLayout layoutP1;
    private SubmitLayout layoutP2;

    private final AtomicInteger frameId = new AtomicInteger(0);
    private final ServerGameSession serverGameSession; // The real simulation engine

    private volatile String activePenalty = null;
    private final Random peniaRandom = new Random();

    private ScheduledFuture<?> gameLoopTask;
    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();

    enum Phase {
        BUILD, COUNTDOWN, MATCH, ENDED
    }

    public PvPGameSession(String matchId, QueuedPlayer p1, QueuedPlayer p2, PvPMatchManager.MatchEventHandler handler) {
        this.matchId = matchId;
        this.player1 = p1;
        this.player2 = p2;
        this.eventHandler = handler;
        // The core change: Create the full simulation engine here.
        this.serverGameSession = new ServerGameSession(matchId);
    }

    public void startBuildPhase() {
        currentPhase = Phase.BUILD;
        buildTimer.set(BUILD_TIME_SECONDS);
        gameLoopTask = executor.scheduleAtFixedRate(this::buildPhaseTick, 0, 1, TimeUnit.SECONDS);
    }

    private void buildPhaseTick() {
        if (currentPhase != Phase.BUILD) return;

        int remaining = buildTimer.decrementAndGet();
        if ((p1Ready.get() && p2Ready.get()) || remaining <= 0) {
            startCountdown();
            return;
        }

        BuildTick tick = new BuildTick(remaining);
        tick.p1Ready = p1Ready.get();
        tick.p2Ready = p2Ready.get();
        tick.extendStage = extendStage.get();
        tick.activePenalty = activePenalty;
        broadcast(tick);
    }

    private void startCountdown() {
        if (gameLoopTask != null) {
            gameLoopTask.cancel(false);
        }
        currentPhase = Phase.COUNTDOWN;

        MatchStart startMsg = new MatchStart(matchId);
        startMsg.opponentBoxes = layoutP2 != null ? layoutP2.boxes : new ArrayList<>();
        startMsg.opponentWires = layoutP2 != null ? layoutP2.wires : new ArrayList<>();
        startMsg.ownWires = layoutP1 != null ? layoutP1.wires : new ArrayList<>();
        eventHandler.sendMessageToPlayer(player1.sessionId, startMsg);

        startMsg.opponentBoxes = layoutP1 != null ? layoutP1.boxes : new ArrayList<>();
        startMsg.opponentWires = layoutP1 != null ? layoutP1.wires : new ArrayList<>();
        startMsg.ownWires = layoutP2 != null ? layoutP2.wires : new ArrayList<>();
        eventHandler.sendMessageToPlayer(player2.sessionId, startMsg);

        executor.schedule(this::startMatch, COUNTDOWN_SECONDS, TimeUnit.SECONDS);
    }

    private void startMatch() {
        currentPhase = Phase.MATCH;
        serverGameSession.startSimulations();
        // The game loop now ticks the full simulation at 60 FPS (16ms)
        gameLoopTask = executor.scheduleAtFixedRate(this::matchTick, 0, 16, TimeUnit.MILLISECONDS);
    }

    private void matchTick() {
        if (currentPhase != Phase.MATCH) return;
        int frame = frameId.incrementAndGet();

        // Tick the server-side GameControllers
        serverGameSession.tick(1.0 / 60.0);

        // Send state snapshots to clients periodically (e.g., every 5 frames)
        if (frame % 5 == 0) {
            sendTickUpdate();
        }

        if (checkEndConditions()) {
            endMatch();
        }
    }

    private void sendTickUpdate() {
        NetworkSnapshot[] snapshots = serverGameSession.captureSnapshots();

        // TODO: Create a new GameStateUpdate message in the protocol
        // For now, we will adapt the old Tick message for compatibility
        Tick tickP1 = new Tick(matchId, frameId.get());
        // tickP1.state = adaptSnapshotToPvPState(snapshots[0], snapshots[1]); // We'll implement this in the next step
        eventHandler.sendMessageToPlayer(player1.sessionId, tickP1);

        Tick tickP2 = new Tick(matchId, frameId.get());
        // tickP2.state = adaptSnapshotToPvPState(snapshots[1], snapshots[0]); // We'll implement this in the next step
        eventHandler.sendMessageToPlayer(player2.sessionId, tickP2);
    }

    private boolean checkEndConditions() {
        // End after 3 minutes (3 * 60 * 60 frames)
        return frameId.get() > MATCH_DURATION_MINUTES * 60 * 60;
    }

    private void endMatch() {
        currentPhase = Phase.ENDED;
        if (gameLoopTask != null) {
            gameLoopTask.cancel(false);
        }
        serverGameSession.stopSimulations();

        // TODO: Extract final scores from snapshots and send MatchEnd message
        // This logic will be more complex and will be handled in the next steps.
    }

    public void handlePlayerMessage(String sessionId, Message message) {
        if (currentPhase == Phase.ENDED) return;
        int playerSide = sessionId.equals(player1.sessionId) ? 1 : 2;

        switch (message.type) {
            case SUBMIT_LAYOUT -> handleSubmitLayout(playerSide, (SubmitLayout) message);
            case READY_STATE -> handleReadyState(playerSide, (ReadyState) message);
            case EXTEND_REQUEST -> handleExtendRequest(sessionId);
            case INJECT -> serverGameSession.applyPlayerAction(playerSide, message);
            // TODO: Add cases for other PlayerAction_* messages
        }
    }

    private void handleSubmitLayout(int playerSide, SubmitLayout layout) {
        if (currentPhase != Phase.BUILD) return;
        if (playerSide == 1) layoutP1 = layout;
        else layoutP2 = layout;
    }

    private void handleReadyState(int playerSide, ReadyState ready) {
        if (currentPhase != Phase.BUILD) return;
        if (playerSide == 1) p1Ready.set(ready.isReady);
        else p2Ready.set(ready.isReady);
    }

    private void handleExtendRequest(String sessionId) {
        if (currentPhase != Phase.BUILD || extendStage.get() >= MAX_EXTENDS) return;
        int newStage = extendStage.incrementAndGet();
        buildTimer.addAndGet(EXTEND_TIME_SECONDS);
        // Penalty logic can be refined later based on the full game state
        activePenalty = "PENIA";
        ExtendGranted granted = new ExtendGranted(newStage, buildTimer.get(), activePenalty);
        eventHandler.sendMessageToPlayer(sessionId, granted);
    }

    private void broadcast(Message message) {
        eventHandler.sendMessageToPlayer(player1.sessionId, message);
        eventHandler.sendMessageToPlayer(player2.sessionId, message);
    }

    public void stop() {
        if (gameLoopTask != null) gameLoopTask.cancel(true);
        executor.shutdownNow();
        if (serverGameSession != null) serverGameSession.stopSimulations();
    }

    public QueuedPlayer getPlayer1() { return player1; }
    public QueuedPlayer getPlayer2() { return player2; }
}