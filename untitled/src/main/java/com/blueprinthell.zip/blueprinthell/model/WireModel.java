package com.blueprinthell.model;

import java.awt.*;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * Runtime model for a wire: holds its two endpoint ports, current geometric {@link WirePath},
 * and the packets travelling on it.  Physics/routing logic has been delegated out:
 * <ul>
 *   <li>Geometry queries → {@link WirePhysics}</li>
 *   <li>Motion & speed  → see {@code MotionStrategy} inside PacketModel</li>
 * </ul>
 */
public class WireModel implements Serializable {
    private static final long serialVersionUID = 4L;

    /* ---------------- immutable association ---------------- */
    private final PortModel src;
    private final PortModel dst;

    /* ---------------- mutable state ---------------- */
    /** Current poly‑line path; first/last points must coincide with port centres. */
    private WirePath path;

    /** Ordered list of packets on this wire. */
    private final List<PacketModel> packets = new ArrayList<>();

    public WireModel(PortModel src, PortModel dst) {
        this.src = src;
        this.dst = dst;
        this.path = buildDefaultPath();
    }

    /* ====================================================================== */
    /*                                Update                                  */
    /* ====================================================================== */

    /** Advances all attached packets; returns those that reached the destination. */
    public List<PacketModel> update(double dt) {
        List<PacketModel> arrived = new ArrayList<>();
        Iterator<PacketModel> it = packets.iterator();
        while (it.hasNext()) {
            PacketModel p = it.next();
            p.advance(dt); // MotionStrategy inside packet handles progress
            if (p.getProgress() >= 1.0) {
                it.remove();
                arrived.add(p);
            }
        }
        return arrived;
    }

    /* ====================================================================== */
    /*                           Packet attachment                             */
    /* ====================================================================== */

    /**
     * Adds a packet to this wire at the given initial progress <code>t∈[0,1]</code>.
     * PacketFactory should have already configured its MotionStrategy/speed.
     */
    public void attachPacket(PacketModel packet, double initialProgress) {
        packets.add(packet);
        packet.attachToWire(this, initialProgress);
    }

    public boolean removePacket(PacketModel p) { return packets.remove(p); }

    /* ====================================================================== */
    /*                               Geometry                                  */
    /* ====================================================================== */

    public double getLength() { return WirePhysics.length(path); }

    public Point  pointAt(double t) { return WirePhysics.pointAt(path, t); }

    public boolean contains(Point p, double tolPx) { return WirePhysics.contains(path, p, tolPx); }

    public WirePath getPath() { return path; }

    /** Replaces the current path; caller must ensure first/last points match ports */
    public void setPath(WirePath newPath) { this.path = newPath; }

    /* Utility to rebuild straight path when constructed or when ports move. */
    private WirePath buildDefaultPath() {
        Point a = centreOf(src);
        Point b = centreOf(dst);
        return new WirePath(java.util.List.of(a, b));
    }

    private static Point centreOf(PortModel pm) {
        return new Point(pm.getX() + pm.getWidth()/2, pm.getY() + pm.getHeight()/2);
    }

    /* ====================================================================== */
    /*                                Accessors                                */
    /* ====================================================================== */

    public List<PacketModel> getPackets()          { return Collections.unmodifiableList(packets); }
    public PortModel        getSrcPort()          { return src; }
    public PortModel        getDstPort()          { return dst; }

    /** Clears packets – used when rewinding timeline or resetting level. */
    public void clearPackets() { packets.clear(); }
}
