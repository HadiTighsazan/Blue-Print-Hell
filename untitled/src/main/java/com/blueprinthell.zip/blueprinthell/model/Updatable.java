package com.blueprinthell.model;


public interface Updatable {

    void update(double dt);
}
