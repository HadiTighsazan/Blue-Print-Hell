package com.blueprinthell.model;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.Serializable;
import java.util.*;
import java.util.List;
import java.util.Queue;
import java.util.ArrayDeque;
import java.util.ArrayList;

/**
 * نمای گرافیکی یک سیستم در شبکه با پورت‌های ورودی/خروجی.
 * علاوه بر منطقِ صف‌بندی، قابلیت درگ برای جابه‌جایی UI را دارد.
 */
public class SystemBox extends GameObject implements Serializable {
    private static final long serialVersionUID = 5L;

    private final List<Port> inPorts = new ArrayList<>();
    private final List<Port> outPorts = new ArrayList<>();
    private final Queue<Packet> buffer = new ArrayDeque<>(5);

    public SystemBox(int x, int y, int w, int h, int inCount, int outCount) {
        super(x, y, w, h);
        setLayout(null);
        createPorts(inCount, outCount);
        setBackground(new Color(0x444444));
        setOpaque(true);

        // پشتیبانی از کشیدن و جابه‌جایی
        MouseAdapter ma = new MouseAdapter() {
            private Point offset;
            @Override public void mousePressed(MouseEvent e) {
                offset = e.getPoint();
            }
            @Override public void mouseDragged(MouseEvent e) {
                int nx = getX() + e.getX() - offset.x;
                int ny = getY() + e.getY() - offset.y;
                setLocation(nx, ny);
                getParent().repaint();
            }
        };
        addMouseListener(ma);
        addMouseMotionListener(ma);
    }

    private void createPorts(int inCnt, int outCnt) {
        int portSize = 14;
        for (int i = 0; i < inCnt; i++) {
            int yOffset = (i + 1) * getHeight() / (inCnt + 1) - portSize / 2;
            Port p = new Port(-portSize, yOffset, portSize, PortShape.SQUARE, true);
            inPorts.add(p);
            add(p);
        }
        for (int i = 0; i < outCnt; i++) {
            int yOffset = (i + 1) * getHeight() / (outCnt + 1) - portSize / 2;
            Port p = new Port(getWidth(), yOffset, portSize, PortShape.SQUARE, false);
            outPorts.add(p);
            add(p);
        }
    }

    public boolean enqueue(Packet p) {
        if (buffer.size() < 5) {
            buffer.add(p);
            return true;
        }
        return false;
    }

    public Packet pollPacket() {
        return buffer.poll();
    }

    public int getBufferSize() {
        return buffer.size();
    }

    public List<Packet> getBuffer() {
        return new ArrayList<>(buffer);
    }

    public void clearBuffer() {
        buffer.clear();
    }

    public List<Port> getInPorts() { return inPorts; }
    public List<Port> getOutPorts() { return outPorts; }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D)g.create();
        g2.setColor(new Color(0x888888));
        g2.fillRect(0, 0, getWidth(), getHeight());
        g2.setColor(Color.WHITE);
        g2.drawRect(0, 0, getWidth()-1, getHeight()-1);
        g2.dispose();
    }
}
