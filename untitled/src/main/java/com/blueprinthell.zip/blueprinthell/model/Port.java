package com.blueprinthell.model;

import javax.swing.*;
import java.awt.*;
import java.io.Serializable;

/**
 * A single port on a SystemBox, with a shape and direction (input/output).
 */
public class Port extends GameObject implements Serializable {
    private static final long serialVersionUID = 3L;
    private final PortShape shape;
    private final boolean input;

    public Port(int x, int y, int size, PortShape shape, boolean input) {
        super(x, y, size, size);
        this.shape = shape;
        this.input = input;
    }

    /** Check if a packet's type matches this port's shape. */
    public boolean isCompatible(Packet p) {
        PacketType t = p.getType();
        return (shape == PortShape.SQUARE && t == PacketType.SQUARE)
                || (shape == PortShape.TRIANGLE && t == PacketType.TRIANGLE);
    }

    /** Returns true if this is an input port. */
    public boolean isInput() {
        return input;
    }

    /** Returns the shape of the port. */
    public PortShape getShape() {
        return shape;
    }

    /** Returns a PacketType corresponding to this port's shape. */
    public PacketType getType() {
        return (shape == PortShape.SQUARE)
                ? PacketType.SQUARE
                : PacketType.TRIANGLE;
    }

    /** Allows any output port to connect to any input port, regardless of shape. */
    public boolean isCompatibleWith(Port other) {
        return !this.input && other.input;
    }

    @Override
    protected void paintComponent(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setColor(input ? Color.GREEN.darker() : Color.BLUE.darker());
        int s = getWidth();
        if (shape == PortShape.SQUARE) {
            g2.fillRect(0, 0, s, s);
        } else {
            g2.fillPolygon(new int[]{0, s/2, s}, new int[]{s, 0, s}, 3);
        }
        g2.dispose();
    }
}