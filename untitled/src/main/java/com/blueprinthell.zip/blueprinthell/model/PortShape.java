package com.blueprinthell.model;


public enum PortShape {
    SQUARE,
    TRIANGLE
}
