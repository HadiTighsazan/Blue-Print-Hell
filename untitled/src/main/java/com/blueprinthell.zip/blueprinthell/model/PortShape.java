package com.blueprinthell.model;

/**
 * Enumeration of port shapes in the domain model.
 */
public enum PortShape {
    SQUARE,
    TRIANGLE
}
